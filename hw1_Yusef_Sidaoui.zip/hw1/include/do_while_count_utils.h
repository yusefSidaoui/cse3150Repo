#ifndef DO_WHILE_COUNT_UTILS
#define DO_WHILE_COUNT_UTILS

namespace do_while_count_utils {
    void runDoWhileCount();
}

#endif
