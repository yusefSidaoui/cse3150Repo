#ifndef STRING_UTILS_H
#define STRING_UTILS_H

namespace string_utils{
    void runStringOption();
}

#endif
