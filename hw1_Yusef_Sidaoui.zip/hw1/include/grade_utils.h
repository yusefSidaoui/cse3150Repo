#ifndef GRADE_UTILS_H
#define GRADE_UTILS_H

namespace grade_utils {
    double calculateGrade();
}

#endif
