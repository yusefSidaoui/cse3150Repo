#ifndef INTEGER_UTILS_H
#define INTEGER_UTILS_H

namespace integer_utils{
	void runIntegerOption();
}

#endif
