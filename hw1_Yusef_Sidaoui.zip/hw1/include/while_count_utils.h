#ifndef WHILE_COUNT_UTILS_H
#define WHILE_COUNT_UTILS_H

namespace while_count_utils {
    void runWhileCount();
}

#endif
